import React, { useState , useEffect , useContext } from "react";
import ItemCounter from "./itemCounter";
import PurchaseButton from '../button/purchaseButton'
import { Link } from "react-router-dom";
import { Context }from '../../context/cartContext'

const ItemDetail = ({itemData})=>{

    const [itemsToAdd, setItemsToAdd] = useContext(Context);
    const isInCart = useContext(Context)
    const [cartReady, setCartReady] = useState(false)//Estado para cambiar el counter
    
    console.log("que es esto "+isInCart)
    //Evento para el boton del counter
    const onAdd = (cartCount)=>{
        itemData.cartcount=cartCount //al objeto item, le agrego el key cartCount
        setItemsToAdd([...itemsToAdd,itemData]) //"..." es un spread operator
        setCartReady(true)
        };
    /**Use efect para mostrar resultados del evento
   useEffect(()=>{
        console.log(itemsToAdd)
        itemsToAdd[1] && console.log("Vas a agregar "+itemsToAdd[1]+" unidades de "+itemsToAdd[0]["title"])
 
    },[itemsToAdd])**/
    
    return( 

        itemData && 
            <React.Fragment>
                <div className="row justify-content-center">
                <h1 className="mt-4">{itemData.title}</h1>
                </div>
                <div className="row justify-content-between p-2">
                    <img src={itemData.src} className="m-2 col-5" width="100" alt="Descripcion de producto"></img>
                    <div className="col-5 m-2">
                        <h3>{itemData["title"]}</h3>
                        <h4 className="text-muted">{itemData.category}</h4>
                        <p>{itemData.description}</p>
                        <h3 className="text-center">$ {itemData.price}</h3>      
                        {cartReady?
                            (<><Link to='/cart'><PurchaseButton></PurchaseButton></Link>
                            <button type="button" className="btn btn-lg btn-success m-3" onClick={isInCart(itemData.id)}>
                            Existe?
                            </button></>)
                            :<ItemCounter  itemData={itemData} handlerClick={onAdd}></ItemCounter>}
                            
                    </div>               
                </div>           
            </React.Fragment>
        
    )
}
/*   */

export default ItemDetail