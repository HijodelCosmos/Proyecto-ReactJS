import React, { useState } from 'react';

export const Context = React.createContext(0)

export const CartContext = ({children})=>{

    const [itemsToAdd, setItemsToAdd] = useState([]);

    const isInCart = (itemId)=>{
        let itemExist =itemsToAdd.find(item => item["id"]=== itemId)
        return(console.log("isInCart= "+itemExist?true:false)) ;}

    return(
        <Context.Provider value={[itemsToAdd , setItemsToAdd, isInCart]}>
            {children}
        </Context.Provider>
    )
}

