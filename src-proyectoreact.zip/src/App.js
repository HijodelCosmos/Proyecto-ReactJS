import React from 'react';
import { BrowserRouter, Switch, Route , Redirect } from "react-router-dom";
//Components
import {NavBar} from './components/navBar/navBar'
import './App.css';
import ItemListContainer from './components/itemContainer/itemListContainer';
import ItemDetailContainer from './components/itemContainer/itemDetailContainer'
//Context
import { CartContext } from './context/cartContext'
//Styles
import 'bootstrap/dist/css/bootstrap.min.css';



function App() {

  return (

      <div className="App">
        <BrowserRouter> 
          <CartContext>
          <NavBar/>
          <Redirect
            from="/Proyecto-ReactJS/"
            to="/" />
          <Switch>
            <React.Fragment>
            <main className="container">
              <Route exact path='/'>
                <ItemListContainer/>
              </Route>  
              <Route exact path='/category:categoryId'>
                <ItemListContainer/>
              </Route>   
              <Route path='/item:itemId'>
                <ItemDetailContainer/>
              </Route>         
            </main>
            </React.Fragment>
          </Switch>
          </CartContext>
        </BrowserRouter>
      </div>
  );
}
export default App;
