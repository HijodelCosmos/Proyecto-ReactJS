import React, {useContext} from 'react';
import cart from '../../assets/img/cart.png'
import { Context }from '../../context/cartContext'

 const CartWidget = () => {
    const [itemsToAdd] = useContext(Context);
    return(
        <div>
            <a href="./#carrito">
                <img className="m-2 tada" src={cart} width="60" alt="Cart Icon"/>
                {(itemsToAdd[1] > 0)&& (<span className="badge badge-danger badge-pill">{itemsToAdd[1]}</span>)}             
            </a>
        </div>)
}

export default CartWidget