import React, { useState } from 'react';

export const Context = React.createContext(0)

export const CartContext = ({children})=>{

    const [itemsToAdd, setItemsToAdd] = useState([]);

    return(
        <Context.Provider value={[itemsToAdd , setItemsToAdd]}>
            {children}
        </Context.Provider>
    )
}

